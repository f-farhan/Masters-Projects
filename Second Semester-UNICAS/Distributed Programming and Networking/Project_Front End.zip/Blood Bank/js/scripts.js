// scripts.js

function searchDonor() {
    // Get form values
    const bloodGroup = document.getElementById('bloodGroup').value;
    const location = document.getElementById('location').value;
    const gender = document.getElementById('gender').value;

    // Dummy data for demonstration
    const donors = [
        { name: 'John Doe', bloodGroup: 'O+', contact: '123-456-7890', location: 'Cassino', gender: 'Male' },
        { name: 'Jane Smith', bloodGroup: 'A-', contact: '987-654-3210', location: 'Rome', gender: 'Female' },
        { name: 'Jim Brown', bloodGroup: 'B+', contact: '456-789-1234', location: 'Napoli', gender: 'Male' },
        { name: 'Lisa White', bloodGroup: 'AB-', contact: '654-321-9876', location: 'Milan', gender: 'Female' }
    ];

    // Filter donors based on form values
    const filteredDonors = donors.filter(donor => {
        return donor.bloodGroup === bloodGroup && donor.location === location && donor.gender === gender;
    });

    // Get table body
    const tableBody = document.getElementById('donorTableBody');
    tableBody.innerHTML = '';

    // Populate table with filtered donors
    filteredDonors.forEach(donor => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${donor.name}</td>
            <td>${donor.bloodGroup}</td>
            <td>${donor.contact}</td>
        `;
        tableBody.appendChild(row);
    });

    // Show modal
    $('#resultModal').modal('show');
}
