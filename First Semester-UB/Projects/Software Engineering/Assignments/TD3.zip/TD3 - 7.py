import tkinter as tk
import math

root = tk.Tk()
root.title('Calculator')

l = []
input_text = ''


def enter(i):
    global l
    global input_text

    # logic for clr

    # condition for clear
    if i=='':
        input_text = ''
        result_label.config(text=input_text)
        l = []
        return

    else:
        input_text += str(i)
        result_label.config(text=input_text)

    try:
        # adding the numbers to the list
        i = int(i)
        if l and type(l[-1]) is int:
            # print(1)
            l[-1] = l[-1]*10 + i

        else:
            l.append(i)

    except:

        # Performing '=' operation
        if i=='=':
            if len(l) <= 1 or (len(l) == 2 and (not l[0] == 'sqrt ')):
                print(not l[0] == 'sqrt')
                result_label.config(text='Improper Input!!')
                l = []
                input_text = ''

            else:
                while True:
                    # print(1)

                    if '*' in l:
                        k = l.index('*')
                        r = l[k - 1] * l[k + 1]
                        l.pop(k + 1)

                    elif '/' in l:
                        k = l.index('/')
                        if l[k + 1]==0:
                            result_label.config(text='Division by zero!!')
                            l = []
                            input_text = ''
                            break

                        r = l[k - 1] / l[k + 1]
                        l.pop(k + 1)

                    elif '-' in l:
                        k = l.index('-')
                        r = l[k - 1] - l[k + 1]
                        l.pop(k + 1)

                    elif '+' in l:
                        k = l.index('+')
                        r = l[k - 1] + l[k + 1]
                        l.pop(k + 1)

                    elif 'sqrt ' in l:
                        k = l.index('sqrt ')
                        if l[k+1]<0:
                            result_label.config(text='Sqrt not possible!!')
                            l = []
                            input_text = ''
                            break

                        r = math.sqrt(l[k+1])

                    l[k - 1] = r
                    l.pop(k)

                    if len(l)==1:

                        result_label.config(text=l[0])
                        l = []
                        input_text = ''
                        break

        else:
            l.append(i)



# Create the interface

result_label = tk.Label(root, text="")
result_label.grid(row=0, columnspan=5, sticky='E')

button1 = tk.Button(root, text="1", command=lambda: enter(1))
button1.grid(row=1, column=0, padx=2, pady=2)

button2 = tk.Button(root, text="2", command=lambda: enter(2))
button2.grid(row=1, column=1, padx=2, pady=2)

button3 = tk.Button(root, text="3", command=lambda: enter(3))
button3.grid(row=1, column=2, padx=2, pady=2)

button4 = tk.Button(root, text="4", command=lambda: enter(4))
button4.grid(row=2, column=0, padx=2, pady=2)

button5 = tk.Button(root, text="5", command=lambda: enter(5))
button5.grid(row=2, column=1, padx=2, pady=2)

button6 = tk.Button(root, text="6", command=lambda: enter(6))
button6.grid(row=2, column=2, padx=2, pady=2)

button7 = tk.Button(root, text="7", command=lambda: enter(7))
button7.grid(row=3, column=0, padx=2, pady=2)

button8 = tk.Button(root, text="8", command=lambda: enter(8))
button8.grid(row=3, column=1, padx=2, pady=2)

button9 = tk.Button(root, text="9", command=lambda: enter(9))
button9.grid(row=3, column=2, padx=2, pady=2)

button0 = tk.Button(root, text="0", command=lambda: enter(0))
button0.grid(row=4, column=0, padx=2, pady=2, columnspan=2, sticky=tk.E+tk.W)

button_plus = tk.Button(root, text="+", command=lambda: enter('+'))
button_plus.grid(row=3, column=3, padx=2, pady=2)

button_sub = tk.Button(root, text="-", command=lambda: enter('-'))
button_sub.grid(row=4, column=3, padx=2, pady=2)

button_mul = tk.Button(root, text="*", command=lambda: enter('*'))
button_mul.grid(row=3, column=4, padx=2, pady=2)

button_div = tk.Button(root, text="/", command=lambda: enter('/'))
button_div.grid(row=4, column=4, padx=2, pady=2)

button_sqrt = tk.Button(root, text="sqrt", command=lambda: enter('sqrt '))
button_sqrt.grid(row=2, column=3, padx=2, pady=2, columnspan=2, sticky=tk.E+tk.W)

button_equal = tk.Button(root, text="=", command=lambda: enter('='))
button_equal.grid(row=4, column=2, padx=2, pady=2)

button_clr = tk.Button(root, text="clr", command=lambda: enter(''))
button_clr.grid(row=1, column=3, padx=2, pady=2, columnspan=2, sticky=tk.E+tk.W)


root.mainloop()