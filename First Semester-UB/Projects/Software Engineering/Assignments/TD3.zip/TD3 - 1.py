import tkinter as tk
root = tk.Tk()
root.title('Intro')

def submit():
    # Get the input values from the entry widgets
    t = title.get()
    f = first.get()
    d = dob.get()

    # Display the input values
    result_label.config(text=f"{t} {f} was born on {d}")

title = tk.Label(root, text="Name:")
title.pack()
title = tk.Entry(root)
title.pack()

first = tk.Label(root, text="First Name:")
first.pack()
first = tk.Entry(root)
first.pack()

dob = tk.Label(root, text="Date of Birth:")
dob.pack()
dob = tk.Entry(root)
dob.pack()

# Create a submit button
submit_button = tk.Button(root, text="Submit", command=submit)
submit_button.pack()

# Create a label to display the result
result_label = tk.Label(root, text="")
result_label.pack()

root.mainloop()