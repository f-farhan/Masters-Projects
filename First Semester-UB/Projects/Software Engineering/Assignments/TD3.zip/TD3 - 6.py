import tkinter as tk
import math

m1 = 20000
m2 = 50000

def on_button_press(event):
    global prev_x, prev_y
    prev_x = event.x
    prev_y = event.y

def calc_dis(l):
    dis_x = abs(l[0] - l[2])
    dis_y = abs(l[1] - l[3])
    dist = math.sqrt(dis_x ** 2 + dis_y ** 2)
    return dist

def calc_force(d):
    global m1, m2
    g = 0.0000000000667
    force = g * m1 * m2 / (d**2)
    return force


def on_button_drag(event, item, i, j):
    global prev_x, prev_y, l

    new_x = event.x
    new_y = event.y
    canvas.move(item, new_x - prev_x, new_y - prev_y)

    l[i] = new_x
    l[j] = new_y
    d = calc_dis(l)
    f = calc_force(d)

    result_label1.config(text='Distance between the stars: ' + str(d))
    result_label2.config(text='Gravitational force: ' + str(f))
    prev_x = new_x
    prev_y = new_y


# Create the main window
root = tk.Tk()
root.title("Distance and force")

result_label3 = tk.Label(root, text="Mass of Red: " + str(m2))
result_label3.pack()

result_label4 = tk.Label(root, text="Mass of Blue: " + str(m1))
result_label4.pack()

result_label5 = tk.Label(root, text="Mass in Kilograms (kgs), Distance in Kilometers (kms) and Force in Newton (N)")
result_label5.pack()

# Create a canvas to place the circular button on
canvas = tk.Canvas(root, width=400, height=400)
canvas.pack()

l = [120, 120, 250, 250]

# Create the circular button using create_oval
button1 = canvas.create_oval(120, 120, 150, 150, fill="blue", outline="black")
button2 = canvas.create_oval(250, 250, 200, 200, fill="red", outline="black")

result_label1 = tk.Label(root, text="")
result_label1.pack()

result_label2 = tk.Label(root, text="")
result_label2.pack()

# Bind the mouse button events to the canvas
canvas.tag_bind(button1, '<ButtonPress-1>', on_button_press)
canvas.tag_bind(button1, '<B1-Motion>', lambda event, item=button1, i=0, j=1: on_button_drag(event, item, i, j))

canvas.tag_bind(button2, '<ButtonPress-1>', on_button_press)
canvas.tag_bind(button2, '<B1-Motion>', lambda event, item=button2, i=2, j=3: on_button_drag(event, item, i, j))

root.mainloop()





