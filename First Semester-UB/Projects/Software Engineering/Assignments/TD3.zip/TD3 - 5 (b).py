import tkinter as tk

def create_ring(canvas, x, y, inner_radius, outer_radius, color):
    canvas.create_oval(x - outer_radius, y - outer_radius, x + outer_radius, y + outer_radius, outline=color, width=3)
    canvas.create_oval(x - inner_radius, y - inner_radius, x + inner_radius, y + inner_radius, outline="")

def ring1():
    create_ring(canvas, 100, 100, 30, 50, "blue")

def ring2():
    create_ring(canvas, 210, 100, 30, 50, "black")

def ring3():
    create_ring(canvas, 320, 100, 30, 50, "red")

def ring4():
    create_ring(canvas, 155, 160, 30, 50, "yellow")

def ring5():
    create_ring(canvas, 265, 160, 30, 50, "green")


def close_window():
    root.destroy()

root = tk.Tk()
root.title("Olympic Rings")

canvas = tk.Canvas(root, width=400, height=250)
canvas.grid(row=0, column=0, padx=10, pady=10)

# Create a ring with center coordinates (100, 100), inner radius 30, and outer radius 50

button1 = tk.Button(root, text="Ring1", command=ring1)
button1.grid()

button2 = tk.Button(root, text="Ring2", command=ring2)
button2.grid()

button3 = tk.Button(root, text="Ring3", command=ring3)
button3.grid()

button4 = tk.Button(root, text="Ring4", command=ring4)
button4.grid()

button5 = tk.Button(root, text="Ring5", command=ring5)
button5.grid()

button6 = tk.Button(root, text="Quit", command=close_window)
button6.grid()

root.mainloop()
