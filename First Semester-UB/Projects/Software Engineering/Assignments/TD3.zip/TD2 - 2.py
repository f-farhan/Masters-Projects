from datetime import datetime
import tkinter as tk

def current_time():
    t = datetime.now()
    time_now = t.strftime("%H:%M:%S")

    display.config(text=time_now)

root = tk.Tk()
root.title('Time')

# Create a button
button = tk.Button(root, text="Current Time", command=current_time)
button.pack()

# Display the time
display = tk.Label(root, text="")
display.pack()

root.mainloop()