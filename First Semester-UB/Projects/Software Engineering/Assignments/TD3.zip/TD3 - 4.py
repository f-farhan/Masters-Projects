import tkinter as tk
from tkinter import ttk

text = None
l = ['blue', 'red1', 'yellow', 'red', 'brown', 'cyan', 'aqua', 'indigo', 'pink', 'purple', 'skyblue']
last = [0, 'skyblue']

# Function to update the search in the list
def on_filter_change(event):
    global text

    value = event.widget.get()
    text = value
    if value=='':
        bg_color['values'] = l
    else:
        data = []
        for item in l:
            if value.lower() in item.lower():
                data.append(item)

        bg_color['values'] = data

# Function to add a new color
def add():
    global text
    global l
    global last

    l.append(text)
    last.pop(0)
    last.append(text)
    # last = bg_color.cget('background')
    canvas.configure(bg=text)

# Function to change the color
def on_select(event):
    global last
    # last = bg_color.cget('background')
    # print(last)
    # print(last)
    selected_item = bg_color.get()
    last.pop(0)
    last.append(selected_item)
    canvas.configure(bg=selected_item)

def last_color():
    global last, l
    # result_label.config(text=last[0])
    if not last[0]==0:
        canvas.configure(bg=last[0])
        item = l.index(last[0])
        bg_color.current(item)


# Creating tkinter window
window = tk.Tk()
window.title('BG color changer')
# window.geometry('500x250')

canvas= tk.Canvas(window, bg='skyblue')
canvas.grid()

ttk.Label(canvas, text="Bonjour! Select the Color:",
          font=("Times New Roman", 10)).grid(column=0,
                                             row=5, padx=10, pady=25)

# Combobox creation
n = tk.StringVar()
bg_color = ttk.Combobox(canvas, width=27, textvariable=n)

# Adding combobox drop down list
bg_color['values'] = l

bg_color.bind("<KeyRelease>", on_filter_change)
bg_color.grid(column=1, row=5)

bg_color.current()

button1 = tk.Button(canvas, text="Add color", command=add)
button1.grid(row=7, column=0)



button2 = tk.Button(canvas, text="Get previous color", command=last_color)
button2.grid(row=10, column=0, pady=8)

# result_label = tk.Label(canvas, text="------")
# result_label.grid(row=10, column=1, pady=8)

bg_color.bind("<<ComboboxSelected>>", on_select)

window.mainloop()

