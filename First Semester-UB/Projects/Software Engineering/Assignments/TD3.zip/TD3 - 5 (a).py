import tkinter as tk

def create_ring(canvas, x, y, inner_radius, outer_radius, color):
    canvas.create_oval(x - outer_radius, y - outer_radius, x + outer_radius, y + outer_radius, outline=color, width=3)
    canvas.create_oval(x - inner_radius, y - inner_radius, x + inner_radius, y + inner_radius, outline="")

def close_window():
    root.destroy()

root = tk.Tk()
root.title("Olympic Rings")

canvas = tk.Canvas(root, width=400, height=250)
canvas.grid(row=0, column=0, padx=10, pady=10)

# Create a ring with center coordinates (100, 100), inner radius 30, and outer radius 50
create_ring(canvas, 100, 100, 30, 50, "blue")

create_ring(canvas, 210, 100, 30, 50, "black")

create_ring(canvas, 320, 100, 30, 50, "red")

create_ring(canvas, 155, 160, 30, 50, "yellow")

create_ring(canvas, 265, 160, 30, 50, "green")

button = tk.Button(root, text="Quit", command=close_window)
button.grid()

root.mainloop()
