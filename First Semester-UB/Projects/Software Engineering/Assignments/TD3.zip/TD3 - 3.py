import tkinter as tk
import numpy as np
out = 'blue'

def circle():
    global out

    r1 = np.random.randint(50, 250)  # x-coordinate of the center of the circle
    r2 = np.random.randint(50, 250)  # x-coordinate of the center of the circle
    radius = np.random.randint(10, 40)  # Radius of the circle

    # Draw the circle on the canvas
    canvas.create_oval(r1 - radius, r2 - radius, r1 + radius, r2 + radius, outline=out, width=2)

def change():
    global out

    l = ['purple', 'cyan', 'green', 'red', 'blue', 'orange', 'black']
    out = np.random.choice(l)



# Create the main application window
root = tk.Tk()
root.title("Draw a Circle")

# Create a Canvas widget
canvas = tk.Canvas(root, width=300, height=300)
canvas.pack()

button1 = tk.Button(root, text="Draw a Circle", command=circle)
button1.pack()

button2 = tk.Button(root, text="Change Color", command=change)
button2.pack()

button3 = tk.Button(root, text="Clear", command=lambda: canvas.delete('all'))
button3.pack()


# Start the Tkinter main loop
root.mainloop()
